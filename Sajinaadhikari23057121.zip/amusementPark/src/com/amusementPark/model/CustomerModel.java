package com.amusementPark.model;

public class CustomerModel {
    private final int id;
    private final String name;
    private final String address;
    private final String contact;
    private final short tickets;

    public CustomerModel(int id, String name, String address, String contact, short tickets) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.contact = contact;
        this.tickets = tickets;
    }

    // Getters and Setters

    /**
     *
     * @return
     */
    public int getid()
    { 
        return id; 
    }
    public String getName() 
    { 
        return name; 
    }
    public String getAddress() 
    { return address; 
    }
    public String getContact() 
    { 
      return contact; 
    }
    
    public short getTickets() 
    { 
      return tickets; 
    }

    public Object getaddress() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setName(String text) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setAddress(String text) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setContact(String text) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setTickets(short parseShort) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}