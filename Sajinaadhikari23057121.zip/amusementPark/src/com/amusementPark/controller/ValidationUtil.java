package com.amusementPark.controller;

import java.util.regex.Pattern;

public class ValidationUtil {

    private static final Pattern NAME_PATTERN = Pattern.compile("^[a-zA-Z]+$");
    private static final Pattern LMU_ID_PATTERN = Pattern.compile("^\\d{7}$");
    private static final Pattern address_PATTERN = Pattern.compile("^[a-zA-Z]+$");
    private static final Pattern CONTACT_PATTERN = Pattern.compile("^98\\d{8}$");
    
    /**
     * Validates if a string is null or empty.
     *
     * @param value the string to validate
     * @return true if the string is null or empty, otherwise false
     */
    public static boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    /**
     * Validates if the name contains only alphabets.
     *
     * @param name the name to validate
     * @return true if valid, otherwise false
     */
    public static boolean isValidName(String name) {
        return !isNullOrEmpty(name) && NAME_PATTERN.matcher(name).matches();
    }

    /**
     * Validates if the LMU ID is exactly 7 digits.
     *
     * @param Id the LMU ID to validate
     * @return true if valid, otherwise false
     */
    public static boolean isValidId(int Id) {
        return LMU_ID_PATTERN.matcher(String.valueOf(Id)).matches();
    }

    /**
     * Validates if the address is one of the allowed options.
     *
     * @param address the address to validate
     * @return true if valid, otherwise false
     */
    public static boolean isValidaddress(String address) {
        return !isNullOrEmpty(address) && address_PATTERN.matcher(address).matches();
    }

    /**
     * Validates if the contact number starts with 98 and has 10 digits in total.
     *
     * @param contact the contact number to validate
     * @return true if valid, otherwise false
     */
    public static boolean isValidContact(String contact) {
        return !isNullOrEmpty(contact) && CONTACT_PATTERN.matcher(contact).matches();
    }


    public static boolean isValidTickets(short tickets) {
        return tickets >= 1 && tickets <= 30;
    }
}